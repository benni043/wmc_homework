import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e7-component',
  templateUrl: './e7-component.component.html',
  styleUrls: ['./e7-component.component.css']
})
export class E7ComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
