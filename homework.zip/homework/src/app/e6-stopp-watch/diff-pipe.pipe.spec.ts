import { DiffPipePipe } from './diff-pipe.pipe';

describe('DiffPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DiffPipePipe();
    expect(pipe).toBeTruthy();
  });
});
